const prisma=require('../prisma');

async function findByEmail(email){
    return prisma.user.findUnique({
        where:{
            email:email
        }
    });

}

async function createUser(name,email,password){
    const user=await prisma.user.create({
        data:{
           name: name,email: email,password: password
        }
    });
    return user.id;
}

module.exports={
    findByEmail,
    createUser
}

